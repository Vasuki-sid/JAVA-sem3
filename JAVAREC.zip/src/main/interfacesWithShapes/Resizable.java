interface Resizable {
    void resizeWidth(int width);
    void resizeHeight(int height);
}