/*
take string as input and calculate the weight of the string as per the following rules
  1)weight of the alphabetic character that appears in the string should be added
  2)weight of bubbles that appears in the string should be ignored
  3)weight of each letter is calculated based on the position 
input string : Hello World
Output :
*/
